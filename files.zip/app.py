from flask import Flask, render_template, request, redirect, url_for, flash
import json
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = "change-this-secret-key"  # Production me ise environment variable se lena

DATA_FILE = os.path.join(os.path.dirname(__file__), "submissions.json")


def save_submission(data):
    """Contact form ka data ek JSON file me save karta hai."""
    submissions = []
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            try:
                submissions = json.load(f)
            except json.JSONDecodeError:
                submissions = []
    submissions.append(data)
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(submissions, f, ensure_ascii=False, indent=2)


@app.route("/", methods=["GET"])
def home():
    return redirect(url_for("contact"))


@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        subject = request.form.get("subject", "").strip()
        message = request.form.get("message", "").strip()

        errors = []
        if not name:
            errors.append("Naam daalna zaroori hai.")
        if not email:
            errors.append("Email daalna zaroori hai.")
        elif "@" not in email or "." not in email:
            errors.append("Sahi email address daalein.")
        if not message:
            errors.append("Message khali nahi ho sakta.")

        if errors:
            for e in errors:
                flash(e, "error")
            return render_template(
                "contact.html",
                name=name, email=email, subject=subject, message=message
            )

        submission = {
            "name": name,
            "email": email,
            "subject": subject,
            "message": message,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        save_submission(submission)

        flash("Aapka message safaltapoorvak bhej diya gaya hai! Hum jaldi hi aapse sampark karenge.", "success")
        return redirect(url_for("contact"))

    return render_template("contact.html", name="", email="", subject="", message="")


if __name__ == "__main__":
    app.run(debug=True)
