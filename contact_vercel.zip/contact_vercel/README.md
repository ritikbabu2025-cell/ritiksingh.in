# Contact Us Page (Python/Flask + Vercel)

## Folder Structure
```
contact_vercel/
├── api/
│   └── index.py        <- Flask app (backend logic)
├── templates/
│   └── contact.html    <- Contact form ka HTML
├── static/
│   └── style.css        <- Styling
├── vercel.json           <- Vercel deployment config
└── requirements.txt      <- Python dependencies
```

## GitHub par upload karne ke steps

1. GitHub par ek naya repository banayein (ya existing repo use karein).
2. Is poore `contact_vercel` folder ka content us repo me daal dein
   (root me `api`, `templates`, `static`, `vercel.json`, `requirements.txt` hone chahiye).
3. GitHub par push/commit kar dein.

## Vercel par deploy karne ke steps

1. https://vercel.com par jaayein aur GitHub account se login karein.
2. "Add New Project" -> apna GitHub repo select karein.
3. Vercel apne aap `vercel.json` aur `requirements.txt` dekh kar Python/Flask
   detect kar lega. Bas "Deploy" par click karein.
4. Deploy hone ke baad ek URL milega, jaise: `https://yourproject.vercel.app`
5. Contact page dekhne ke liye: `https://yourproject.vercel.app/contact`

## Apni existing website me link karna

Agar aapki website already Vercel par hai aur ye contact form usi project
ka hissa banana hai, toh bas is folder ka content apne existing project
repo me merge kar dein (routes clash na ho iska dhyan rakhein), phir
apni site ke navigation/menu me `/contact` ka link daal dein, jaise:

```html
<a href="/contact">Contact Us</a>
```

## Important Note

Vercel serverless environment me local file (jaise `submissions.json`)
permanently save nahi hoti. Agar aapko form submissions email par
chahiye, toh `api/index.py` ke `send_notification()` function me
SMTP ya email service (Resend/SendGrid) ka code add karna hoga.
