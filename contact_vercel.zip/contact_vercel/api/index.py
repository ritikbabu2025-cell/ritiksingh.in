from flask import Flask, render_template, request, redirect, url_for, flash
import os

# Vercel par templates/static ka sahi path set karna zaroori hai
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "templates"),
    static_folder=os.path.join(BASE_DIR, "static"),
)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key")


@app.route("/", methods=["GET"])
def home():
    return redirect(url_for("contact"))


@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        subject = request.form.get("subject", "").strip()
        message = request.form.get("message", "").strip()

        errors = []
        if not name:
            errors.append("Naam daalna zaroori hai.")
        if not email:
            errors.append("Email daalna zaroori hai.")
        elif "@" not in email or "." not in email:
            errors.append("Sahi email address daalein.")
        if not message:
            errors.append("Message khali nahi ho sakta.")

        if errors:
            for e in errors:
                flash(e, "error")
            return render_template(
                "contact.html",
                name=name, email=email, subject=subject, message=message
            )

        # NOTE: Vercel serverless environment me local file system
        # permanent nahi hota (har request par reset ho sakta hai).
        # Isliye submissions ko email ya external service (Google Sheet,
        # Airtable, database) me bhejna best practice hai.
        # Neeche is function ko customize karke email bhejne ka option hai.
        send_notification(name, email, subject, message)

        flash("Aapka message safaltapoorvak bhej diya gaya hai! Hum jaldi hi aapse sampark karenge.", "success")
        return redirect(url_for("contact"))

    return render_template("contact.html", name="", email="", subject="", message="")


def send_notification(name, email, subject, message):
    """
    Yahan aap email/SMTP ya kisi bhi service (SendGrid, Resend, etc.)
    ka code daal sakte hain taaki submission aapko mil jaaye.
    Abhi ke liye ye sirf server logs me print karta hai.
    """
    print(f"New contact submission: {name} <{email}> - {subject} - {message}")


# Vercel is 'app' object ko dhundta hai
if __name__ == "__main__":
    app.run(debug=True)
